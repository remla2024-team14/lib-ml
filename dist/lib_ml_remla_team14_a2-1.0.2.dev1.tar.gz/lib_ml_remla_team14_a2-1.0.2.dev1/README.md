# lib_ml_remla_team14_a2

lib-mllib-ml-remla-team14-a2 contains pre-processing logic for data used in our ML training pipeline.

## Features

- Tokenization of text data at a character level.
- Padding of text sequences to uniform lengths.

## Installation

Install lib_ml_remla_team14_a2 using pip:

```bash
pip install lib_ml_remla_team14_a2
```
